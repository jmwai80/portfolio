from django.apps import AppConfig


class JohnConfig(AppConfig):
    name = 'john'
